ClimaCell Weather Code Icons License
-------------------------

# Icons
ClimaCell Weather Code Icons collection is free, open source according
to the CC BY 4.0 License (https://creativecommons.org/licenses/by/4.0/)

# Attribution
Attribution is required by CC BY licenses. Make sure to add a backlink to display the message
“Powered by ClimaCell” or any of the images in this repository in any application or service which incorporates the icons.
Whenever possible, open a link to www.climacell.co/weather-api upon click or tap.
